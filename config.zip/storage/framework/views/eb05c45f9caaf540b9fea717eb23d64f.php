<?php $__env->startSection('title', 'Admin Accounts'); ?>
<?php $__env->startSection('page-title', 'Admin Accounts'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/patients.css?v=' . time())); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/users.css?v=' . time())); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">

        <!-- Admin Creation Options -->
        <div class="admin-options-container">
            <div class="option-card">
                <div class="option-icon">
                    <i class="bi bi-person-plus-fill"></i>
                </div>
                <h3>Add New User as Admin</h3>
                <p>Create a brand new user account and assign the Admin role</p>
                <a href="<?php echo e(route('users.add-new')); ?>" class="btn btn-primary btn-block">
                    <i class="bi bi-person-plus"></i> Create New Admin
                </a>
            </div>

            <div class="option-card">
                <div class="option-icon">
                    <i class="bi bi-person-gear"></i>
                </div>
                <h3>Set Existing User as Admin</h3>
                <p>Promote an existing user account to Admin role</p>
                <button class="btn btn-secondary btn-block" onclick="openSetAdminModal()">
                    <i class="bi bi-arrow-up-circle"></i> Promote to Admin
                </button>
            </div>
        </div>

        <!-- Search Section -->
        <div class="filters">
            <div class="search-box">
                <input type="text" placeholder="Search admin accounts..." class="search-input">
                <button class="btn btn-primary"><i class="bi bi-search"></i> Search</button>
                <a href="<?php echo e(route('users.add-new')); ?>" class="btn btn-primary">
                    <i class="bi bi-person-plus"></i> Add New User
                </a>
            </div>

            <div class="filter-options">
                <select class="filter-select">
                    <option value="">All Status</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
        </div>



        <!-- Admin Accounts Table -->
        <div class="table-container">
            <div style="overflow-x: auto;">
                <table class="data-table" style="min-width: 800px;">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Position</th>
                            <th>Status</th>
                            <th>Created Date</th>
                            <th>Last Login</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $admins ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $fullName = trim(($admin->first_name ?? '') . ' ' . ($admin->middle_name ? $admin->middle_name . ' ' : '') . ($admin->last_name ?? '')) ?: ($admin->name ?? 'N/A');
                            ?>
                            <tr>
                                <td><?php echo e($admin->username ?? 'N/A'); ?></td>
                                <td><?php echo e($fullName); ?></td>
                                <td><?php echo e($admin->email ?? 'N/A'); ?></td>
                                <td>System Administrator</td>
                                <td>
                                    <?php if(($admin->status ?? 'inactive') === 'active'): ?>
                                        <span class="status-badge status-active">Active</span>
                                    <?php else: ?>
                                        <span class="status-badge status-inactive">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(optional($admin->created_at)->format('M d, Y') ?? 'N/A'); ?></td>
                                <td>—</td>
                                <td class="actions">
                                    <a href="javascript:void(0)" class="btn-action btn-view view-user"
                                        data-id="<?php echo e($admin->id); ?>">View</a>
                                    <a href="<?php echo e(route('users.edit', $admin->id)); ?>" class="btn-action btn-edit">Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" style="text-align:center;">No admin accounts found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- Set Admin Modal -->
    <div id="setAdminModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Promote User to Admin</h3>
                <span class="close-modal" onclick="closeSetAdminModal()">&times;</span>
            </div>
            <form method="POST" action="<?php echo e(route('users.promote-admin')); ?>" class="role-form">
                <?php echo csrf_field(); ?>

                <div class="form-section">
                    <h4 class="section-header"><span class="section-indicator"></span>Select User to Promote</h4>

                    <div class="form-group">
                        <label for="user_id">Select User *</label>
                        <select id="user_id" name="user_id" class="form-control" required>
                            <option value="">-- Select a User --</option>
                            <?php $__currentLoopData = \App\Models\User::whereNotIn('role', ['admin', 'super_admin'])->orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $fullName = trim(($user->first_name ?? '') . ' ' . ($user->middle_name ? $user->middle_name . ' ' : '') . ($user->last_name ?? '')) ?: $user->name;
                                ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->username); ?> - <?php echo e($fullName); ?>

                                    (<?php echo e(strtoupper($user->role)); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="form-text">Only non-admin users are shown in this list</small>
                    </div>

                    <div class="info-box">
                        <h4><i class="bi bi-info-circle"></i> Important</h4>
                        <p>Promoting a user to Admin will grant them management-level access to:</p>
                        <ul>
                            <li>Manage all patient records</li>
                            <li>Generate and export reports</li>
                            <li>View system analytics</li>
                        </ul>
                        <p><strong>Note:</strong> They will NOT be able to manage users or access super admin settings.</p>
                    </div>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeSetAdminModal()">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-arrow-up-circle"></i> Promote to Admin
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openSetAdminModal() {
            document.getElementById('setAdminModal').style.display = 'block';
        }

        function closeSetAdminModal() {
            document.getElementById('setAdminModal').style.display = 'none';
        }

        // Close modal when clicking outside
        window.onclick = function (event) {
            const modal = document.getElementById('setAdminModal');
            if (event.target == modal) {
                closeSetAdminModal();
            }
        }
    </script>

    <?php echo $__env->make('users.partials.view-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\source\repos\IT12_Brgy_HealthCareMS\resources\views\users\admin-accounts.blade.php ENDPATH**/ ?>