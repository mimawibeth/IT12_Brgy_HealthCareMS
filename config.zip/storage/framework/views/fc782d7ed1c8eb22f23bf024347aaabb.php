<?php $__env->startSection('title', 'Edit Family Planning Record'); ?>
<?php $__env->startSection('page-title', 'Edit FP Record'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/patients.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="form-container">
            <h2 class="form-title">Editing FP Record #<?php echo e($record->record_no ?? ('FP-' . str_pad($record->id, 3, '0', STR_PAD_LEFT))); ?></h2>
            <form class="patient-form" method="POST" action="<?php echo e(route('health-programs.family-planning-update', $record)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-section section-patient-info">
                    <h3 class="section-header"><span class="section-indicator"></span>Client Details</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="fp_client_name">Client Name</label>
                            <input type="text" id="fp_client_name" name="fp_client_name" class="form-control" value="<?php echo e(old('fp_client_name', $record->client_name)); ?>">
                        </div>
                        <div class="form-group">
                            <label for="fp_type">Client Type</label>
                            <select id="fp_type" name="fp_type" class="form-control">
                                <option value="">Select</option>
                                <option value="new" <?php if(old('fp_type', $record->client_type) === 'new'): echo 'selected'; endif; ?>>New Acceptor</option>
                                <option value="current" <?php if(old('fp_type', $record->client_type) === 'current'): echo 'selected'; endif; ?>>Current User</option>
                                <option value="changing" <?php if(old('fp_type', $record->client_type) === 'changing'): echo 'selected'; endif; ?>>Changing Method</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="fp_reason">Reason</label>
                            <?php ($reasons = (array) ($record->reason ?? [])); ?>
                            <select id="fp_reason" class="form-control" disabled>
                                <option><?php echo e(implode(', ', $reasons) ?: '—'); ?></option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="form-section section-assessment">
                    <h3 class="section-header"><span class="section-indicator"></span>Assessment Notes</h3>
                    <div class="form-row">
                        <div class="form-group full-width">
                            <label for="fp_exam_findings">Physical Examination Findings / Notes</label>
                            <textarea id="fp_exam_findings" name="fp_exam_findings" class="form-control" rows="4"><?php echo e(old('fp_exam_findings', $record->exam_findings)); ?></textarea>
                        </div>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Update Record</button>
                    <a href="<?php echo e(route('health-programs.family-planning-view')); ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\source\repos\IT12_Brgy_HealthCareMS\resources\views\health-programs\family-planning-edit.blade.php ENDPATH**/ ?>