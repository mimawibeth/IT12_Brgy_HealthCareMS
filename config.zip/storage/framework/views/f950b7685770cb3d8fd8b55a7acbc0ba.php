<?php $__env->startSection('title', 'User Details'); ?>
<?php $__env->startSection('page-title', 'User Details'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/users.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">

        <!-- Detail Container -->
        <div class="detail-container">
            <div class="detail-header">
                <div>
                    <h2 class="detail-title">User Account Information</h2>
                    <p class="detail-subtitle">Complete details of the user account</p>
                </div>
                <div class="detail-actions">
                    <a href="<?php echo e(route('users.all-users')); ?>" class="btn btn-secondary">
                        <i class="bi bi-arrow-left"></i> Back to List
                    </a>
                    <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn btn-primary">
                        <i class="bi bi-pencil"></i> Edit User
                    </a>
                </div>
            </div>

            <!-- Account Information Section -->
            <div class="detail-section">
                <h3 class="section-header"><span class="section-indicator"></span>Account Information</h3>

                <div class="detail-grid">
                    <div class="detail-item">
                        <label>Username</label>
                        <p><?php echo e($user->username); ?></p>
                    </div>
                    <div class="detail-item">
                        <label>Email Address</label>
                        <p><?php echo e($user->email); ?></p>
                    </div>
                    <div class="detail-item">
                        <label>User Role</label>
                        <p>
                            <?php
                                $roleBadges = [
                                    'super_admin' => ['label' => 'Super Admin', 'class' => 'badge-super-admin'],
                                    'admin' => ['label' => 'Admin', 'class' => 'badge-admin'],
                                    'bhw' => ['label' => 'BHW', 'class' => 'badge-bhw'],
                                ];
                                $roleMeta = $roleBadges[$user->role] ?? ['label' => ucfirst($user->role), 'class' => 'badge-admin'];
                            ?>
                            <span class="badge <?php echo e($roleMeta['class']); ?>"><?php echo e($roleMeta['label']); ?></span>
                        </p>
                    </div>
                    <div class="detail-item">
                        <label>Account Status</label>
                        <p>
                            <?php if($user->status === 'active'): ?>
                                <span class="status-badge status-active">Active</span>
                            <?php else: ?>
                                <span class="status-badge status-inactive">Inactive</span>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>

            <!-- Personal Information Section -->
            <div class="detail-section">
                <h3 class="section-header"><span class="section-indicator"></span>Personal Information</h3>

                <div class="detail-grid">
                    <div class="detail-item">
                        <label>First Name</label>
                        <p><?php echo e($user->first_name ?? '—'); ?></p>
                    </div>
                    <div class="detail-item">
                        <label>Middle Name</label>
                        <p><?php echo e($user->middle_name ?? '—'); ?></p>
                    </div>
                    <div class="detail-item">
                        <label>Last Name</label>
                        <p><?php echo e($user->last_name ?? '—'); ?></p>
                    </div>
                    <div class="detail-item">
                        <label>Full Name</label>
                        <p><?php echo e($user->name); ?></p>
                    </div>
                    <div class="detail-item">
                        <label>Contact Number</label>
                        <p><?php echo e($user->contact_number ?? '—'); ?></p>
                    </div>
                </div>
            </div>

            <!-- Activity Information Section -->
            <div class="detail-section">
                <h3 class="section-header"><span class="section-indicator"></span>Activity Information</h3>

                <div class="detail-grid">
                    <div class="detail-item">
                        <label>Account Created</label>
                        <p><?php echo e(optional($user->created_at)->format('F d, Y \a\t g:i A') ?? '—'); ?></p>
                    </div>
                    <div class="detail-item">
                        <label>Last Updated</label>
                        <p><?php echo e(optional($user->updated_at)->format('F d, Y \a\t g:i A') ?? '—'); ?></p>
                    </div>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\source\repos\IT12_Brgy_HealthCareMS\resources\views\users\show.blade.php ENDPATH**/ ?>