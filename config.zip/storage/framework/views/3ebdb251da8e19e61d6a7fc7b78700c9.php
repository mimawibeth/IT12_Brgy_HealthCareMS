<?php $__env->startSection('title', 'Approvals'); ?>
<?php $__env->startSection('page-title', 'Approvals'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/patients.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/approvals.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <!-- Header Actions -->
        <div class="content-header"
            style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
            <div></div>
            <?php if(auth()->user()->role === 'bhw'): ?>
                <div class="header-actions" style="display: flex; gap: 0.5rem;">
                    <a href="<?php echo e(route('approvals.financial.create')); ?>" class="btn btn-primary">
                        <i class="bi bi-plus-circle"></i> Request Financial Assistance
                    </a>
                    <a href="<?php echo e(route('approvals.medical.create')); ?>" class="btn btn-primary">
                        <i class="bi bi-plus-circle"></i> Request Medical Supplies
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success"
                style="background: #d4edda; color: #155724; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem; border-left: 4px solid #28a745;">
                <i class="bi bi-check-circle"></i> <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Financial Assistance Requests Section -->
        <div class="table-container" style="margin-bottom: 2rem;">
            <div style="padding: 1.5rem; background: #f8f9fa; border-bottom: 2px solid #e9ecef;">
                <h3 style="margin: 0; font-size: 1.25rem; font-weight: 600; color: #2c3e50;">
                    <i class="bi bi-cash-stack"></i> Financial Assistance Requests
                </h3>
            </div>

            <?php if($financialRequests->count() > 0): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Request ID</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Reason</th>
                            <?php if(auth()->user()->role === 'bhw'): ?>
                                <th>Submitted</th>
                                <th>Status</th>
                            <?php elseif(auth()->user()->role === 'admin'): ?>
                                <th>Submitted By</th>
                                <th>Status</th>
                                <th>Actions</th>
                            <?php else: ?>
                                <th>Submitted By</th>
                                <th>Admin Notes</th>
                                <th>Status</th>
                                <th>Actions</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $financialRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>#<?php echo e($request->id); ?></td>
                                <td><?php echo e($request->type); ?></td>
                                <td>₱<?php echo e(number_format($request->amount, 2)); ?></td>
                                <td><?php echo e(Str::limit($request->reason, 50)); ?></td>
                                <?php if(auth()->user()->role === 'bhw'): ?>
                                    <td><?php echo e($request->submitted_at->format('M d, Y')); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo e($request->getStatusBadge()['class']); ?>">
                                            <?php echo e($request->getStatusBadge()['label']); ?>

                                        </span>
                                    </td>
                                <?php elseif(auth()->user()->role === 'admin'): ?>
                                    <td><?php echo e($request->requestor->name ?? 'N/A'); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo e($request->getStatusBadge()['class']); ?>">
                                            <?php echo e($request->getStatusBadge()['label']); ?>

                                        </span>
                                    </td>
                                    <td class="actions">
                                        <?php if($request->isPending()): ?>
                                            <button class="btn-action btn-view approve-btn" data-type="financial"
                                                data-id="<?php echo e($request->id); ?>" title="Forward to Superadmin">
                                                <i class="bi bi-check-circle"></i>
                                            </button>
                                            <button class="btn-action btn-delete reject-btn" data-type="financial"
                                                data-id="<?php echo e($request->id); ?>" title="Reject">
                                                <i class="bi bi-x-circle"></i>
                                            </button>
                                        <?php else: ?>
                                            <span style="color: #7f8c8d; font-size: 0.875rem;">Reviewed</span>
                                        <?php endif; ?>
                                    </td>
                                <?php else: ?>
                                    <td><?php echo e($request->requestor->name ?? 'N/A'); ?></td>
                                    <td><?php echo e($request->admin_notes ? Str::limit($request->admin_notes, 30) : '—'); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo e($request->getStatusBadge()['class']); ?>">
                                            <?php echo e($request->getStatusBadge()['label']); ?>

                                        </span>
                                    </td>
                                    <td class="actions">
                                        <?php if($request->isAwaitingSuperadminReview()): ?>
                                            <button class="btn-action btn-view approve-btn" data-type="financial"
                                                data-id="<?php echo e($request->id); ?>" title="Approve">
                                                <i class="bi bi-check-circle"></i>
                                            </button>
                                            <button class="btn-action btn-delete reject-btn" data-type="financial"
                                                data-id="<?php echo e($request->id); ?>" title="Reject">
                                                <i class="bi bi-x-circle"></i>
                                            </button>
                                            <button class="btn-action btn-edit view-btn" data-type="financial" data-id="<?php echo e($request->id); ?>"
                                                title="View Details">
                                                <i class="bi bi-eye"></i>
                                            </button>
                                        <?php else: ?>
                                            <span style="color: #7f8c8d; font-size: 0.875rem;">Finalized</span>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="100%" style="text-align: center; padding: 2rem; color: #7f8c8d;">
                                    <i class="bi bi-inbox"
                                        style="font-size: 48px; display: block; margin-bottom: 10px; opacity: 0.5;"></i>
                                    No financial assistance requests found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; padding: 2rem; color: #7f8c8d;">
                    <i class="bi bi-info-circle"
                        style="font-size: 48px; display: block; margin-bottom: 10px; opacity: 0.5;"></i>
                    No financial assistance requests at this time.
                </div>
            <?php endif; ?>
        </div>

        <!-- Medical Supplies Requests Section -->
        <div class="table-container">
            <div style="padding: 1.5rem; background: #f8f9fa; border-bottom: 2px solid #e9ecef;">
                <h3 style="margin: 0; font-size: 1.25rem; font-weight: 600; color: #2c3e50;">
                    <i class="bi bi-box-seam"></i> Medical Supplies Requests
                </h3>
            </div>

            <?php if($medicalRequests->count() > 0): ?>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Request ID</th>
                            <th>Item</th>
                            <th>Quantity</th>
                            <th>Reason</th>
                            <?php if(auth()->user()->role === 'bhw'): ?>
                                <th>Submitted</th>
                                <th>Status</th>
                            <?php elseif(auth()->user()->role === 'admin'): ?>
                                <th>Submitted By</th>
                                <th>Status</th>
                                <th>Actions</th>
                            <?php else: ?>
                                <th>Submitted By</th>
                                <th>Admin Notes</th>
                                <th>Status</th>
                                <th>Actions</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $medicalRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>#<?php echo e($request->id); ?></td>
                                <td><?php echo e($request->item_name); ?></td>
                                <td><?php echo e($request->quantity); ?></td>
                                <td><?php echo e(Str::limit($request->reason, 50)); ?></td>
                                <?php if(auth()->user()->role === 'bhw'): ?>
                                    <td><?php echo e($request->submitted_at->format('M d, Y')); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo e($request->getStatusBadge()['class']); ?>">
                                            <?php echo e($request->getStatusBadge()['label']); ?>

                                        </span>
                                    </td>
                                <?php elseif(auth()->user()->role === 'admin'): ?>
                                    <td><?php echo e($request->requestor->name ?? 'N/A'); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo e($request->getStatusBadge()['class']); ?>">
                                            <?php echo e($request->getStatusBadge()['label']); ?>

                                        </span>
                                    </td>
                                    <td class="actions">
                                        <?php if($request->isPending()): ?>
                                            <button class="btn-action btn-view approve-btn" data-type="medical" data-id="<?php echo e($request->id); ?>"
                                                title="Forward to Superadmin">
                                                <i class="bi bi-check-circle"></i>
                                            </button>
                                            <button class="btn-action btn-delete reject-btn" data-type="medical"
                                                data-id="<?php echo e($request->id); ?>" title="Reject">
                                                <i class="bi bi-x-circle"></i>
                                            </button>
                                        <?php else: ?>
                                            <span style="color: #7f8c8d; font-size: 0.875rem;">Reviewed</span>
                                        <?php endif; ?>
                                    </td>
                                <?php else: ?>
                                    <td><?php echo e($request->requestor->name ?? 'N/A'); ?></td>
                                    <td><?php echo e($request->admin_notes ? Str::limit($request->admin_notes, 30) : '—'); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo e($request->getStatusBadge()['class']); ?>">
                                            <?php echo e($request->getStatusBadge()['label']); ?>

                                        </span>
                                    </td>
                                    <td class="actions">
                                        <?php if($request->isAwaitingSuperadminReview()): ?>
                                            <button class="btn-action btn-view approve-btn" data-type="medical" data-id="<?php echo e($request->id); ?>"
                                                title="Approve">
                                                <i class="bi bi-check-circle"></i>
                                            </button>
                                            <button class="btn-action btn-delete reject-btn" data-type="medical"
                                                data-id="<?php echo e($request->id); ?>" title="Reject">
                                                <i class="bi bi-x-circle"></i>
                                            </button>
                                            <button class="btn-action btn-edit view-btn" data-type="medical" data-id="<?php echo e($request->id); ?>"
                                                title="View Details">
                                                <i class="bi bi-eye"></i>
                                            </button>
                                        <?php else: ?>
                                            <span style="color: #7f8c8d; font-size: 0.875rem;">Finalized</span>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="100%" style="text-align: center; padding: 2rem; color: #7f8c8d;">
                                    <i class="bi bi-inbox"
                                        style="font-size: 48px; display: block; margin-bottom: 10px; opacity: 0.5;"></i>
                                    No medical supplies requests found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; padding: 2rem; color: #7f8c8d;">
                    <i class="bi bi-info-circle"
                        style="font-size: 48px; display: block; margin-bottom: 10px; opacity: 0.5;"></i>
                    No medical supplies requests at this time.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Details Modal -->
    <div class="modal fade" id="detailsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">Request Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="modalBody">
                    <p>Loading...</p>
                </div>
                <div class="modal-footer" id="modalFooter">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const modal = new bootstrap.Modal(document.getElementById('detailsModal'));
                const userRole = '<?php echo e(auth()->user()->role); ?>';

                // View details button
                document.querySelectorAll('.view-btn').forEach(btn => {
                    btn.addEventListener('click', function () {
                        const type = this.dataset.type;
                        const id = this.dataset.id;
                        loadRequestDetails(type, id);
                    });
                });

                // Approve button
                document.querySelectorAll('.approve-btn').forEach(btn => {
                    btn.addEventListener('click', function () {
                        const type = this.dataset.type;
                        const id = this.dataset.id;
                        const endpoint = userRole === 'admin'
                            ? `/approvals/${type}/${id}/admin-approve`
                            : `/approvals/${type}/${id}/superadmin-approve`;

                        approveRequest(type, id, endpoint);
                    });
                });

                // Reject button
                document.querySelectorAll('.reject-btn').forEach(btn => {
                    btn.addEventListener('click', function () {
                        const type = this.dataset.type;
                        const id = this.dataset.id;
                        const endpoint = userRole === 'admin'
                            ? `/approvals/${type}/${id}/admin-reject`
                            : `/approvals/${type}/${id}/superadmin-reject`;

                        rejectRequest(type, id, endpoint);
                    });
                });

                function loadRequestDetails(type, id) {
                    fetch(`/approvals/${type}/${id}`)
                        .then(response => response.json())
                        .then(data => {
                            displayRequestDetails(data, type);
                            modal.show();
                        })
                        .catch(error => console.error('Error:', error));
                }

                function displayRequestDetails(request, type) {
                    let content = `
                                <div class="request-details">
                                    <div class="detail-section">
                                        <h6>Requestor Information</h6>
                                        <p><strong>Name:</strong> ${request.requestor?.name || 'N/A'}</p>
                                    </div>
                            `;

                    if (type === 'financial') {
                        content += `
                                    <div class="detail-section">
                                        <h6>Financial Assistance Details</h6>
                                        <p><strong>Type:</strong> ${request.type}</p>
                                        <p><strong>Amount:</strong> ₱${parseFloat(request.amount).toFixed(2)}</p>
                                        <p><strong>Reason:</strong> ${request.reason}</p>
                                        <p><strong>Description:</strong> ${request.description || 'N/A'}</p>
                                    </div>
                                `;
                    } else {
                        content += `
                                    <div class="detail-section">
                                        <h6>Medical Supplies Details</h6>
                                        <p><strong>Item:</strong> ${request.item_name}</p>
                                        <p><strong>Quantity:</strong> ${request.quantity}</p>
                                        <p><strong>Reason:</strong> ${request.reason}</p>
                                        <p><strong>Description:</strong> ${request.description || 'N/A'}</p>
                                    </div>
                                `;
                    }

                    if (request.admin) {
                        content += `
                                    <div class="detail-section">
                                        <h6>Admin Review</h6>
                                        <p><strong>Reviewed By:</strong> ${request.admin.name}</p>
                                        <p><strong>Reviewed At:</strong> ${new Date(request.admin_reviewed_at).toLocaleString()}</p>
                                        <p><strong>Notes:</strong> ${request.admin_notes || 'N/A'}</p>
                                    </div>
                                `;
                    }

                    content += `</div>`;
                    document.getElementById('modalBody').innerHTML = content;
                    document.getElementById('modalTitle').textContent = `${type === 'financial' ? 'Financial Assistance' : 'Medical Supplies'} Request Details`;
                }

                function approveRequest(type, id, endpoint) {
                    if (!confirm('Are you sure you want to approve this request?')) return;

                    fetch(endpoint, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ notes: '' })
                    })
                        .then(response => response.json())
                        .then(data => {
                            alert('Request approved successfully!');
                            location.reload();
                        })
                        .catch(error => console.error('Error:', error));
                }

                function rejectRequest(type, id, endpoint) {
                    if (!confirm('Are you sure you want to reject this request?')) return;

                    fetch(endpoint, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ notes: '' })
                    })
                        .then(response => response.json())
                        .then(data => {
                            alert('Request rejected.');
                            location.reload();
                        })
                        .catch(error => console.error('Error:', error));
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
    </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\source\repos\IT12_Brgy_HealthCareMS\resources\views\approvals\index.blade.php ENDPATH**/ ?>