<?php $__env->startSection('title', 'Dispense History'); ?>
<?php $__env->startSection('page-title', 'Dispense History'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/patients.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/medicine.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="content-header"></div>

        <div style="margin: 1.5rem 0;">
            <form method="GET" action="<?php echo e(route('medicine.dispense')); ?>" class="patient-form" style="padding: 1rem;">
                <div class="form-section section-patient-info">
                    <h3 class="section-header">
                        <span class="section-indicator"></span>Filter Dispense History
                    </h3>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="filter_medicine_id">Medicine</label>
                            <select id="filter_medicine_id" name="medicine_id" class="form-control">
                                <option value="">All Medicines</option>
                                <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($medicine->id); ?>" <?php if(request('medicine_id') == $medicine->id): echo 'selected'; endif; ?>>
                                        <?php echo e($medicine->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="from_date">From Date</label>
                            <input type="date" id="from_date" name="from_date" class="form-control"
                                value="<?php echo e(request('from_date')); ?>">
                        </div>

                        <div class="form-group">
                            <label for="to_date">To Date</label>
                            <input type="date" id="to_date" name="to_date" class="form-control"
                                value="<?php echo e(request('to_date')); ?>">
                        </div>

                        <div class="form-group">
                            <label for="filter_dispensed_to">Dispensed To</label>
                            <input type="text" id="filter_dispensed_to" name="dispensed_to" class="form-control"
                                value="<?php echo e(request('dispensed_to')); ?>" placeholder="Patient name or ID">
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Apply Filters</button>
                        <a href="<?php echo e(route('medicine.dispense')); ?>" class="btn btn-secondary">Clear</a>
                    </div>
                </div>
            </form>
        </div>

        <div class="table-container">

            <table class="data-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Medicine</th>
                        <th>Quantity</th>
                        <th>Dispensed To</th>
                        <th>Reference No.</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $dispenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(optional($dispense->dispensed_at)->format('M d, Y') ?? $dispense->created_at->format('M d, Y')); ?>

                            </td>
                            <td><?php echo e($dispense->medicine->name ?? 'N/A'); ?></td>
                            <td><?php echo e($dispense->quantity); ?> <?php echo e($dispense->medicine->unit ?? ''); ?></td>
                            <td><?php echo e($dispense->dispensed_to ?: '—'); ?></td>
                            <td><?php echo e($dispense->reference_no ?: '—'); ?></td>
                            <td><?php echo e($dispense->remarks ?: '—'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 40px; color: #7f8c8d;">
                                <i class="bi bi-inbox"
                                    style="font-size: 48px; display: block; margin-bottom: 10px; opacity: 0.5;"></i>
                                No dispenses recorded yet.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php
            $showPagination = !empty($dispenses) && method_exists($dispenses, 'hasPages') && $dispenses->hasPages();
        ?>
        <?php if($showPagination): ?>
            <div class="pagination">
                <?php if($dispenses->onFirstPage()): ?>
                    <button class="btn-page" disabled>« Previous</button>
                <?php else: ?>
                    <a class="btn-page" href="<?php echo e($dispenses->previousPageUrl()); ?>">« Previous</a>
                <?php endif; ?>

                <?php
                    $start = max(1, $dispenses->currentPage() - 2);
                    $end = min($dispenses->lastPage(), $dispenses->currentPage() + 2);
                ?>

                <?php for($page = $start; $page <= $end; $page++): ?>
                    <?php if($page === $dispenses->currentPage()): ?>
                        <span class="btn-page active"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a class="btn-page" href="<?php echo e($dispenses->url($page)); ?>"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endfor; ?>

                <span class="page-info">
                    Page <?php echo e($dispenses->currentPage()); ?> of <?php echo e($dispenses->lastPage()); ?> (<?php echo e($dispenses->total()); ?> total
                    dispenses)
                </span>

                <?php for($page = $start; $page <= $end; $page++): ?>
                    <?php if($page === $dispenses->currentPage()): ?>
                        <span class="btn-page active"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a class="btn-page" href="<?php echo e($dispenses->url($page)); ?>"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endfor; ?>

                <span class="page-info">
                    Page <?php echo e($dispenses->currentPage()); ?> of <?php echo e($dispenses->lastPage()); ?> (<?php echo e($dispenses->total()); ?> total
                    records)
                </span>

                <?php if($dispenses->hasMorePages()): ?>
                    <a class="btn-page" href="<?php echo e($dispenses->nextPageUrl()); ?>">Next »</a>
                <?php else: ?>
                    <button class="btn-page" disabled>Next »</button>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\source\repos\IT12_Brgy_HealthCareMS\resources\views\medicine\dispense.blade.php ENDPATH**/ ?>