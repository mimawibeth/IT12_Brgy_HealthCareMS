<?php $__env->startSection('title', 'Settings'); ?>
<?php $__env->startSection('page-title', 'Settings'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
       

        <form method="POST" action="<?php echo e(route('settings.update')); ?>" class="patient-form">
            <?php echo csrf_field(); ?>

            <div class="card" style="margin-bottom: 20px;">
                <h3>Display Preferences</h3>

                <div class="form-group">
                    <label for="dark_mode">Color Theme</label>
                    <select id="dark_mode" name="dark_mode" class="form-control">
                        <option value="0" <?php if(!(auth()->user()->dark_mode ?? false)): echo 'selected'; endif; ?>>Light Mode</option>
                        <option value="1" <?php if(auth()->user()->dark_mode ?? false): echo 'selected'; endif; ?>>Dark Mode</option>
                    </select>
                </div>

                <p style="font-size: 13px; color: #7f8c8d;">Dark mode applies to this account only and updates the colors of
                    the dashboard, side navigation, and content areas.</p>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Save Settings</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\source\repos\IT12_Brgy_HealthCareMS\resources\views\settings\index.blade.php ENDPATH**/ ?>