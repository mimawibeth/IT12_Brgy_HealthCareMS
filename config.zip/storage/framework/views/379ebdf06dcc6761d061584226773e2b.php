<?php $__env->startSection('title', 'Monthly Reports'); ?>
<?php $__env->startSection('page-title', 'Monthly Reports'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/patients.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/reports.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <!-- Header -->
        <div class="content-header">

            <div class="header-actions">
                <button class="btn btn-secondary" onclick="printReport()">
                    <i class="bi bi-printer"></i> Print Report
                </button>
                <button class="btn btn-primary" onclick="exportReport()">
                    <i class="bi bi-download"></i> Export Report
                </button>
            </div>
        </div>

        <!-- Summary Statistics -->
        <div class="stats-grid">
            <div class="stat-card stat-card-primary">
                <div class="stat-icon">
                    <i class="bi bi-people"></i>
                </div>
                <div class="stat-details">
                    <div class="stat-value"><?php echo e(number_format($totalPatients ?? 0)); ?></div>
                    <div class="stat-label">Total Patients</div>
                    <div class="stat-change"><?php echo e($selectedMonthLabel ?? ''); ?></div>
                </div>
            </div>

            <div class="stat-card stat-card-danger">
                <div class="stat-icon">
                    <i class="bi bi-heart-pulse"></i>
                </div>
                <div class="stat-details">
                    <div class="stat-value"><?php echo e(number_format($prenatalCount ?? 0)); ?></div>
                    <div class="stat-label">Prenatal Consultations</div>
                    <div class="stat-change"><?php echo e($selectedMonthLabel ?? ''); ?></div>
                </div>
            </div>

            <div class="stat-card stat-card-success">
                <div class="stat-icon">
                    <i class="bi bi-shield-check"></i>
                </div>
                <div class="stat-details">
                    <div class="stat-value"><?php echo e(number_format($nipCount ?? 0)); ?></div>
                    <div class="stat-label">Immunizations Given</div>
                    <div class="stat-change"><?php echo e($selectedMonthLabel ?? ''); ?></div>
                </div>
            </div>

            <div class="stat-card stat-card-info">
                <div class="stat-icon">
                    <i class="bi bi-people-fill"></i>
                </div>
                <div class="stat-details">
                    <div class="stat-value"><?php echo e(number_format($fpCount ?? 0)); ?></div>
                    <div class="stat-label">Family Planning Clients</div>
                    <div class="stat-change"><?php echo e($selectedMonthLabel ?? ''); ?></div>
                </div>
            </div>
        </div>

        <!-- Report Filter Section -->
        <div class="filters">
            <form id="report-filters-form" method="GET" action="<?php echo e(route('reports.monthly')); ?>">
                <div class="filter-options">
                    <select name="month" class="filter-select">
                        <?php for($m = 1; $m <= 12; $m++): ?>
                            <?php
                                $label = \Carbon\Carbon::create(2000, $m, 1)->format('F');
                            ?>
                            <option value="<?php echo e($m); ?>" <?php if(($selectedMonthValue ?? null) == $m): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endfor; ?>
                    </select>
                    <select name="year" class="filter-select">
                        <?php for($y = now()->year; $y >= now()->year - 5; $y--): ?>
                            <option value="<?php echo e($y); ?>" <?php if(($selectedYearValue ?? null) == $y): echo 'selected'; endif; ?>><?php echo e($y); ?></option>
                        <?php endfor; ?>
                    </select>
                    <select name="type" class="filter-select">
                        <option value="summary">Summary Report</option>
                        <option value="patients">Patient Statistics</option>
                        <option value="prenatal">Prenatal Services</option>
                        <option value="fp">Family Planning</option>
                        <option value="immunization">Immunization</option>
                        <option value="medicine">Medicine Inventory</option>
                    </select>
                    <button class="btn btn-primary" type="submit">
                        <i class="bi bi-file-earmark-bar-graph"></i> Generate Report
                    </button>
                </div>
            </form>
        </div>

        <!-- Charts Section -->
        <div class="charts-section-title">
            <h2>Statistical Analysis & Trends</h2>
            <p>Visual representation of health center data and performance metrics</p>
        </div>

        <div class="charts-grid">
            <!-- Monthly Services Trend -->
            <div class="chart-card" data-chart-id="servicesChart" data-chart-title="Monthly Services Trend"
                data-chart-icon="bi-graph-up" data-chart-period="Last 6 Months"
                data-chart-description="Overall service delivery trends across all programs">
                <div class="chart-header">
                    <h3><i class="bi bi-graph-up"></i> Monthly Services Trend</h3>
                    <span class="chart-period">Last 6 Months</span>
                </div>
                <div class="chart-placeholder">
                    <canvas id="servicesChart"></canvas>
                    <p>Overall service delivery trends across all programs</p>
                </div>
            </div>

            <!-- Program Distribution -->
            <div class="chart-card" data-chart-id="programDistributionChart" data-chart-title="Health Program Distribution"
                data-chart-icon="bi-pie-chart" data-chart-period="<?php echo e($selectedMonthLabel ?? 'Current Month'); ?>"
                data-chart-description="Service breakdown by health programs">
                <div class="chart-header">
                    <h3><i class="bi bi-pie-chart"></i> Health Program Distribution</h3>
                    <span class="chart-period"><?php echo e($selectedMonthLabel ?? 'Current Month'); ?></span>
                </div>
                <div class="chart-placeholder">
                    <canvas id="programDistributionChart"></canvas>
                    <p>Service breakdown by health programs</p>
                </div>
            </div>

            <!-- Patient Demographics -->
            <div class="chart-card" data-chart-id="demographicsChart" data-chart-title="Patient Demographics"
                data-chart-icon="bi-people" data-chart-period="Age Group Distribution"
                data-chart-description="Patient breakdown by age groups">
                <div class="chart-header">
                    <h3><i class="bi bi-people"></i> Patient Demographics</h3>
                    <span class="chart-period">Age Group Distribution</span>
                </div>
                <div class="chart-placeholder">
                    <canvas id="demographicsChart"></canvas>
                    <p>Patient breakdown by age groups</p>
                </div>
            </div>

            <!-- Service Completion Rate -->
            <div class="chart-card" data-chart-id="completionChart" data-chart-title="Service Completion Rate"
                data-chart-icon="bi-check-circle" data-chart-period="<?php echo e($selectedMonthLabel ?? 'Current Month'); ?>"
                data-chart-description="Completed vs Pending services">
                <div class="chart-header">
                    <h3><i class="bi bi-check-circle"></i> Service Completion Rate</h3>
                    <span class="chart-period"><?php echo e($selectedMonthLabel ?? 'Current Month'); ?></span>
                </div>
                <div class="chart-placeholder">
                    <canvas id="completionChart"></canvas>
                    <p>Completed vs Pending services</p>
                </div>
            </div>

            <!-- Top Health Programs -->
            <div class="chart-card" data-chart-id="topProgramsChart" data-chart-title="Top Health Programs"
                data-chart-icon="bi-bar-chart" data-chart-period="Cases Handled"
                data-chart-description="Most active health programs this month">
                <div class="chart-header">
                    <h3><i class="bi bi-bar-chart"></i> Top Health Programs</h3>
                    <span class="chart-period">Cases Handled</span>
                </div>
                <div class="chart-placeholder">
                    <canvas id="topProgramsChart"></canvas>
                    <p>Most active health programs this month</p>
                </div>
            </div>

            <!-- Gender Distribution -->
            <div class="chart-card" data-chart-id="genderChart" data-chart-title="Gender Distribution"
                data-chart-icon="bi-gender-ambiguous" data-chart-period="Patient Statistics"
                data-chart-description="Male vs Female patient breakdown">
                <div class="chart-header">
                    <h3><i class="bi bi-gender-ambiguous"></i> Gender Distribution</h3>
                    <span class="chart-period">Patient Statistics</span>
                </div>
                <div class="chart-placeholder">
                    <canvas id="genderChart"></canvas>
                    <p>Male vs Female patient breakdown</p>
                </div>
            </div>
        </div>

        <!-- Chart Zoom Modal -->
        <div id="chartModal" class="chart-modal">
            <div class="chart-modal-overlay"></div>
            <div class="chart-modal-content">
                <div class="chart-modal-header">
                    <h3 id="modalChartTitle"></h3>
                    <span id="modalChartPeriod" class="chart-period"></span>
                    <button class="chart-modal-close" id="closeModal">
                        <i class="bi bi-x-lg"></i>
                    </button>
                </div>
                <div class="chart-modal-body">
                    <canvas id="modalChartCanvas"></canvas>
                    <p id="modalChartDescription"></p>
                </div>
            </div>
        </div>

        <!-- Detailed Statistics Table -->
        <div class="report-section">
            <div class="table-container">
                <table class="report-table">
                    <thead>
                        <tr>
                            <th>Program/Service</th>
                            <th>Total Cases</th>
                            <th>New Cases</th>
                            <th>Follow-ups</th>
                            <th>Completed</th>
                            <th>Pending</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Prenatal Care</strong></td>
                            <td><?php echo e($prenatalCount ?? 0); ?></td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                        </tr>
                        <tr>
                            <td><strong>Family Planning</strong></td>
                            <td><?php echo e($fpCount ?? 0); ?></td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                        </tr>
                        <tr>
                            <td><strong>Immunization (NIP)</strong></td>
                            <td><?php echo e($nipCount ?? 0); ?></td>
                            <td>—</td>
                            <td>—</td>
                            <td><?php echo e($nipCount ?? 0); ?></td>
                            <td>0</td>
                        </tr>
                        <?php
                            $totalCases = ($prenatalCount ?? 0) + ($fpCount ?? 0) + ($nipCount ?? 0);
                        ?>
                        <tr class="table-total">
                            <td><strong>TOTAL</strong></td>
                            <td><strong><?php echo e($totalCases); ?></strong></td>
                            <td><strong>—</strong></td>
                            <td><strong>—</strong></td>
                            <td><strong>—</strong></td>
                            <td><strong>—</strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Age Distribution Report -->
        <div class="report-section">
            <div class="table-container">
                <?php
                    $grandMale = array_sum($ageMale ?? []);
                    $grandFemale = array_sum($ageFemale ?? []);
                    $grandTotal = $grandMale + $grandFemale;
                ?>
                <table class="report-table">
                    <thead>
                        <tr>
                            <th>Age Group</th>
                            <th>Male</th>
                            <th>Female</th>
                            <th>Total</th>
                            <th>Percentage</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = ($ageLabels ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $male = $ageMale[$i] ?? 0;
                                $female = $ageFemale[$i] ?? 0;
                                $total = $male + $female;
                                $percent = $grandTotal > 0 ? round(($total / $grandTotal) * 100, 1) : 0;
                            ?>
                            <tr>
                                <td><strong><?php echo e($label); ?></strong></td>
                                <td><?php echo e($male); ?></td>
                                <td><?php echo e($female); ?></td>
                                <td><?php echo e($total); ?></td>
                                <td><?php echo e($percent); ?>%</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table-total">
                            <td><strong>TOTAL</strong></td>
                            <td><strong><?php echo e($grandMale); ?></strong></td>
                            <td><strong><?php echo e($grandFemale); ?></strong></td>
                            <td><strong><?php echo e($grandTotal); ?></strong></td>
                            <td><strong><?php echo e($grandTotal > 0 ? '100%' : '0%'); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Chart configuration
        const chartOptions = {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    labels: {
                        font: { size: 12 },
                        usePointStyle: true,
                        padding: 15
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    padding: 12,
                    titleFont: { size: 14 },
                    bodyFont: { size: 13 }
                }
            }
        };

        const monthLabels = <?php echo json_encode($monthLabels ?? [], 15, 512) ?>;
        const prenatalSeries = <?php echo json_encode($prenatalSeries ?? [], 15, 512) ?>;
        const fpSeries = <?php echo json_encode($fpSeries ?? [], 15, 512) ?>;
        const nipSeries = <?php echo json_encode($nipSeries ?? [], 15, 512) ?>;

        // Initialize Monthly Services Trend Chart
        const servicesCtx = document.getElementById('servicesChart');
        if (servicesCtx) {
            new Chart(servicesCtx.getContext('2d'), {
                type: 'line',
                data: {
                    labels: monthLabels,
                    datasets: [
                        {
                            label: 'Prenatal Care',
                            data: prenatalSeries,
                            borderColor: '#e74c3c',
                            backgroundColor: 'rgba(231, 76, 60, 0.1)',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.4
                        },
                        {
                            label: 'Family Planning',
                            data: fpSeries,
                            borderColor: '#3498db',
                            backgroundColor: 'rgba(52, 152, 219, 0.1)',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.4
                        },
                        {
                            label: 'Immunization',
                            data: nipSeries,
                            borderColor: '#2ecc71',
                            backgroundColor: 'rgba(46, 204, 113, 0.1)',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.4
                        }
                    ]
                },
                options: {
                    ...chartOptions,
                    scales: {
                        y: { beginAtZero: true }
                    }
                }
            });
        }

        // Initialize Program Distribution Chart
        const programCtx = document.getElementById('programDistributionChart');
        if (programCtx) {
            new Chart(programCtx.getContext('2d'), {
                type: 'doughnut',
                data: {
                    labels: ['Prenatal Care', 'Family Planning', 'Immunization'],
                    datasets: [{
                        data: [
                                    <?php echo e($programDistribution['prenatal'] ?? 0); ?>,
                                    <?php echo e($programDistribution['fp'] ?? 0); ?>,
                                    <?php echo e($programDistribution['nip'] ?? 0); ?>,
                        ],
                        backgroundColor: [
                            '#e74c3c',
                            '#3498db',
                            '#2ecc71',
                            '#f39c12',
                            '#9b59b6'
                        ],
                        borderColor: '#fff',
                        borderWidth: 2
                    }]
                },
                options: chartOptions
            });
        }

        // Initialize Patient Demographics Chart
        const ageLabels = <?php echo json_encode($ageLabels ?? [], 15, 512) ?>;
        const ageMale = <?php echo json_encode($ageMale ?? [], 15, 512) ?>;
        const ageFemale = <?php echo json_encode($ageFemale ?? [], 15, 512) ?>;

        const demographicsCtx = document.getElementById('demographicsChart');
        if (demographicsCtx) {
            new Chart(demographicsCtx.getContext('2d'), {
                type: 'bar',
                data: {
                    labels: ageLabels,
                    datasets: [
                        {
                            label: 'Male',
                            data: ageMale,
                            backgroundColor: '#3498db',
                            borderColor: '#2980b9',
                            borderWidth: 1
                        },
                        {
                            label: 'Female',
                            data: ageFemale,
                            backgroundColor: '#e74c3c',
                            borderColor: '#c0392b',
                            borderWidth: 1
                        }
                    ]
                },
                options: {
                    ...chartOptions,
                    scales: {
                        y: { beginAtZero: true }
                    }
                }
            });
        }


        // Initialize Service Completion Rate Chart
        const completionCtx = document.getElementById('completionChart');
        if (completionCtx) {
            new Chart(completionCtx.getContext('2d'), {
                type: 'doughnut',
                data: {
                    labels: ['Completed', 'Pending', 'Follow-ups'],
                    datasets: [{
                        data: <?php echo json_encode($completionData ?? [0, 0, 0]) ?>,
                        backgroundColor: [
                            '#2ecc71',
                            '#e74c3c',
                            '#f39c12'
                        ],
                        borderColor: '#fff',
                        borderWidth: 3
                    }]
                },
                options: chartOptions
            });
        }

        // Initialize Top Health Programs Chart
        const topProgramsCtx = document.getElementById('topProgramsChart');
        if (topProgramsCtx) {
            new Chart(topProgramsCtx.getContext('2d'), {
                type: 'bar',
                data: {
                    labels: ['Deworming', 'Immunization', 'Prenatal Care', 'Family Planning', 'Nutrition'],
                    datasets: [{
                        label: 'Cases Handled',
                        data: <?php echo json_encode($topProgramsData ?? [], 15, 512) ?>,
                        backgroundColor: ['#3498db', '#2ecc71', '#e74c3c', '#9b59b6', '#f39c12'],
                        borderColor: ['#2980b9', '#27ae60', '#c0392b', '#8e44ad', '#d68910'],
                        borderWidth: 1,
                        borderRadius: 6
                    }]
                },
                options: {
                    ...chartOptions,
                    indexAxis: 'y',
                    scales: {
                        x: { beginAtZero: true }
                    }
                }
            });
        }

        // Initialize Gender Distribution Chart
        const genderCtx = document.getElementById('genderChart');
        if (genderCtx) {
            new Chart(genderCtx.getContext('2d'), {
                type: 'pie',
                data: {
                    labels: ['Female', 'Male'],
                    datasets: [{
                        data: [
                                                <?php echo e($genderCounts['F'] ?? 0); ?>,
                                                <?php echo e($genderCounts['M'] ?? 0); ?>,
                        ],
                        backgroundColor: ['#e74c3c', '#3498db'],
                        borderColor: '#fff',
                        borderWidth: 3
                    }]
                },
                options: chartOptions
            });
        }

        // Store chart instances
        const chartInstances = {};

        // Function to get chart instance by canvas ID
        function getChartInstance(canvasId) {
            const canvas = document.getElementById(canvasId);
            if (!canvas) return null;

            // Get Chart.js instance from canvas
            const chart = Chart.getChart(canvas);
            return chart;
        }

        // Function to clone chart to modal
        function cloneChartToModal(originalChart, modalCanvas) {
            if (!originalChart) return null;

            // Get the original chart configuration
            const config = originalChart.config;

            // Create new config for modal
            const modalConfig = {
                type: config.type,
                data: JSON.parse(JSON.stringify(config.data)), // Deep clone data
                options: {
                    ...config.options,
                    maintainAspectRatio: true,
                    responsive: true,
                    plugins: {
                        ...config.options.plugins,
                        legend: {
                            ...config.options.plugins?.legend,
                            display: true
                        }
                    }
                }
            };

            // Destroy existing chart if any
            const existingChart = Chart.getChart(modalCanvas);
            if (existingChart) {
                existingChart.destroy();
            }

            // Create new chart in modal
            return new Chart(modalCanvas.getContext('2d'), modalConfig);
        }

        // Modal functionality
        const modal = document.getElementById('chartModal');
        const closeModalBtn = document.getElementById('closeModal');
        const modalTitle = document.getElementById('modalChartTitle');
        const modalPeriod = document.getElementById('modalChartPeriod');
        const modalDescription = document.getElementById('modalChartDescription');
        const modalCanvas = document.getElementById('modalChartCanvas');

        // Open modal function
        function openChartModal(chartCard) {
            try {
                const chartId = chartCard.getAttribute('data-chart-id');
                const chartTitle = chartCard.getAttribute('data-chart-title');
                const chartIcon = chartCard.getAttribute('data-chart-icon');
                const chartPeriod = chartCard.getAttribute('data-chart-period');
                const chartDescription = chartCard.getAttribute('data-chart-description');

                console.log('Opening modal for chart:', chartId);

                // Get original chart instance
                const originalChart = getChartInstance(chartId);

                if (!originalChart) {
                    console.error('Chart not found:', chartId);
                    alert('Chart not yet loaded. Please wait a moment and try again.');
                    return;
                }

                // Check if modal elements exist
                if (!modal || !modalTitle || !modalPeriod || !modalDescription || !modalCanvas) {
                    console.error('Modal elements not found');
                    return;
                }

                // Set modal content
                modalTitle.innerHTML = `<i class="bi ${chartIcon}"></i> ${chartTitle}`;
                modalPeriod.textContent = chartPeriod;
                modalDescription.textContent = chartDescription;

                // Show modal
                modal.classList.add('active');
                document.body.style.overflow = 'hidden';

                // Clone chart to modal after a short delay to ensure modal is visible
                setTimeout(() => {
                    try {
                        cloneChartToModal(originalChart, modalCanvas);
                    } catch (error) {
                        console.error('Error cloning chart:', error);
                    }
                }, 200);
            } catch (error) {
                console.error('Error opening modal:', error);
            }
        }

        // Close modal function
        function closeChartModal() {
            modal.classList.add('closing');
            document.body.style.overflow = '';

            setTimeout(() => {
                modal.classList.remove('active', 'closing');

                // Destroy modal chart
                const modalChart = Chart.getChart(modalCanvas);
                if (modalChart) {
                    modalChart.destroy();
                }
            }, 300);
        }

        // Initialize modal functionality after DOM is ready and charts are loaded
        function initializeModalFunctionality() {
            console.log('Initializing modal functionality...');

            // Check if modal elements exist
            if (!modal) {
                console.error('Modal element not found!');
                return;
            }

            // Wait a bit to ensure all charts are initialized
            setTimeout(() => {
                // Add click event listeners to chart cards
                const chartCards = document.querySelectorAll('.chart-card');
                console.log('Found chart cards:', chartCards.length);

                if (chartCards.length === 0) {
                    console.error('No chart cards found!');
                    return;
                }

                chartCards.forEach((card, index) => {
                    card.style.cursor = 'pointer';
                    const chartId = card.getAttribute('data-chart-id');
                    console.log(`Setting up click handler for card ${index + 1}: ${chartId}`);

                    card.addEventListener('click', function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        console.log('Chart card clicked:', chartId);
                        openChartModal(this);
                    });
                });

                // Close modal events
                if (closeModalBtn) {
                    closeModalBtn.addEventListener('click', function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        closeChartModal();
                    });
                } else {
                    console.error('Close modal button not found!');
                }

                const overlay = modal.querySelector('.chart-modal-overlay');
                if (overlay) {
                    overlay.addEventListener('click', function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        closeChartModal();
                    });
                } else {
                    console.error('Modal overlay not found!');
                }

                // Close modal on Escape key
                document.addEventListener('keydown', function (e) {
                    if (e.key === 'Escape' && modal.classList.contains('active')) {
                        closeChartModal();
                    }
                });

                console.log('Modal functionality initialized successfully!');
            }, 1000); // Increased delay to ensure charts are fully initialized
        }

        // Initialize when DOM is ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function () {
                setTimeout(initializeModalFunctionality, 100);
            });
        } else {
            setTimeout(initializeModalFunctionality, 100);
        }

        // Report Functions
        function exportReport() {
            alert('Export functionality will be implemented with backend');
        }

        function printReport() {
            window.print();
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\source\repos\IT12_Brgy_HealthCareMS\resources\views\reports\index.blade.php ENDPATH**/ ?>