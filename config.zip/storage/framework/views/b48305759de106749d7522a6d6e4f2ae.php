<?php $__env->startSection('title', 'Edit User'); ?>
<?php $__env->startSection('page-title', 'Edit User'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/users.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">

        <!-- Form Container -->
        <div class="form-container compact-form">
            <div class="form-header">
                <h2 class="form-title"><i class="bi bi-person-gear"></i> Edit User Account</h2>
                <p class="form-subtitle">Update user information below</p>
            </div>

            <?php if($errors->any()): ?>
                <div class="alert alert-error">
                    <ul style="margin: 0; padding-left: 20px;">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('users.update', $user)); ?>" class="user-form">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Account Credentials -->
                <div class="form-section compact-section">
                    <h3 class="section-header"><i class="bi bi-shield-lock"></i> Account Credentials</h3>

                    <div class="form-row two-col">
                        <div class="form-group">
<<<<<<< HEAD
                            <label for="username"><i class="bi bi-person-badge"></i> Username *</label>
                            <input type="text" id="username" name="username" class="form-control" required value="admin01"
=======
                            <label for="username">Username *</label>
                            <input type="text" id="username" name="username" class="form-control" required value="<?php echo e(old('username', $user->username)); ?>"
>>>>>>> 3723e67444b4297a57b2a8d141a24e107def6990
                                readonly>
                            <small class="form-text text-muted">Cannot be changed</small>
                        </div>

                        <div class="form-group">
                            <label for="email"><i class="bi bi-envelope"></i> Email Address *</label>
                            <input type="email" id="email" name="email" class="form-control" required
                                value="<?php echo e(old('email', $user->email)); ?>">
                        </div>
                    </div>

                    <div class="form-row two-col">
                        <div class="form-group">
                            <label for="password"><i class="bi bi-key"></i> New Password</label>
                            <input type="password" id="password" name="password" class="form-control"
<<<<<<< HEAD
                                placeholder="Leave blank to keep current">
=======
                                placeholder="Leave blank to keep current password">
                            <small class="form-text">Only fill if you want to change password (min 12 chars, must include uppercase, lowercase, number, and special character)</small>
>>>>>>> 3723e67444b4297a57b2a8d141a24e107def6990
                        </div>

                        <div class="form-group">
                            <label for="password_confirmation"><i class="bi bi-key-fill"></i> Confirm Password</label>
                            <input type="password" id="password_confirmation" name="password_confirmation"
                                class="form-control" placeholder="Re-enter new password">
                        </div>
                    </div>
                </div>

                <!-- Personal Details -->
                <div class="form-section compact-section">
                    <h3 class="section-header"><i class="bi bi-person-vcard"></i> Personal Details</h3>

                    <div class="form-row three-col">
                        <div class="form-group">
                            <label for="first_name">First Name *</label>
                            <input type="text" id="first_name" name="first_name" class="form-control" required value="<?php echo e(old('first_name', $user->first_name)); ?>">
                        </div>

                        <div class="form-group">
                            <label for="middle_name">Middle Name</label>
                            <input type="text" id="middle_name" name="middle_name" class="form-control" value="<?php echo e(old('middle_name', $user->middle_name)); ?>">
                        </div>

                        <div class="form-group">
                            <label for="last_name">Last Name *</label>
                            <input type="text" id="last_name" name="last_name" class="form-control" required
                                value="<?php echo e(old('last_name', $user->last_name)); ?>">
                        </div>
                    </div>

                    <div class="form-row three-col">
                        <div class="form-group">
<<<<<<< HEAD
                            <label for="contact_number"><i class="bi bi-telephone"></i> Contact Number</label>
                            <input type="text" id="contact_number" name="contact_number" class="form-control"
                                value="0912-345-6789">
                        </div>

                        <div class="form-group col-span-2">
                            <label for="address"><i class="bi bi-geo-alt"></i> Address</label>
                            <input type="text" id="address" name="address" class="form-control"
                                value="123 Barangay Street, City">
=======
                            <label for="contact_number">Contact Number *</label>
                            <input type="text" id="contact_number" name="contact_number" class="form-control" required
                                value="<?php echo e(old('contact_number', $user->contact_number)); ?>">
>>>>>>> 3723e67444b4297a57b2a8d141a24e107def6990
                        </div>
                    </div>
                </div>

                <!-- Role & Access -->
                <div class="form-section compact-section">
                    <h3 class="section-header"><i class="bi bi-gear"></i> Role & Access</h3>

                    <div class="form-row two-col">
                        <div class="form-group">
                            <label for="role"><i class="bi bi-person-check"></i> User Role *</label>
                            <select id="role" name="role" class="form-control" required>
                                <option value="">Select Role</option>
<<<<<<< HEAD
                                <option value="admin" selected>Admin</option>
                                <option value="bhw">Barangay Health Worker</option>
                                <option value="staff">Staff</option>
=======
                                <option value="super_admin" <?php if(old('role', $user->role) === 'super_admin'): echo 'selected'; endif; ?>>Super Admin</option>
                                <option value="admin" <?php if(old('role', $user->role) === 'admin'): echo 'selected'; endif; ?>>Admin</option>
                                <option value="bhw" <?php if(old('role', $user->role) === 'bhw'): echo 'selected'; endif; ?>>Barangay Health Worker (BHW)</option>
>>>>>>> 3723e67444b4297a57b2a8d141a24e107def6990
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="status"><i class="bi bi-toggle-on"></i> Status *</label>
                            <select id="status" name="status" class="form-control" required>
                                <option value="active" <?php if(old('status', $user->status) === 'active'): echo 'selected'; endif; ?>>Active</option>
                                <option value="inactive" <?php if(old('status', $user->status) === 'inactive'): echo 'selected'; endif; ?>>Inactive</option>
                            </select>
                        </div>
                    </div>
<<<<<<< HEAD

                    <div class="form-row">
                        <div class="form-group full-width">
                            <label for="notes"><i class="bi bi-chat-left-text"></i> Notes/Remarks</label>
                            <textarea id="notes" name="notes" class="form-control"
                                rows="2">Primary system administrator responsible for user management and system configuration.</textarea>
                        </div>
                    </div>
=======
>>>>>>> 3723e67444b4297a57b2a8d141a24e107def6990
                </div>

                <!-- Form Actions -->
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="window.history.back()">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save"></i> Update User
                    </button>
                </div>

            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\source\repos\IT12_Brgy_HealthCareMS\resources\views\users\edit.blade.php ENDPATH**/ ?>