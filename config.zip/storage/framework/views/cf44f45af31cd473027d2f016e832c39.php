


<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/patients.css?v=' . time())); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css?v=' . time())); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">


        <?php
            $role = auth()->user()->role ?? 'bhw';
        ?>

        <!-- Overview Cards: Display quick statistics -->
        <div class="stats-grid">
            <!-- Total Registered Patients Card -->
            <div class="stat-card">
                <div class="stat-icon stat-icon-blue">
                    <i class="bi bi-people"></i>
                </div>
                <div class="stat-details">
                    <div class="stat-value"><?php echo e(number_format($registeredPatients ?? 0)); ?></div>
                    <div class="stat-label">Registered Patients</div>
                    <div class="stat-change">Total ITR Records</div>
                </div>
            </div>

            <!-- Active Health Programs Card -->
            <div class="stat-card">
                <div class="stat-icon stat-icon-green">
                    <i class="bi bi-heart-pulse"></i>
                </div>
                <div class="stat-details">
                    <div class="stat-value"><?php echo e(number_format($healthPrograms ?? 0)); ?></div>
                    <div class="stat-label">Health Programs</div>
                    <div class="stat-change">Active Participants</div>
                </div>
            </div>

            <!-- Monthly Services Card -->
            <div class="stat-card">
                <div class="stat-icon stat-icon-purple">
                    <i class="bi bi-clipboard2-pulse"></i>
                </div>
                <div class="stat-details">
                    <div class="stat-value"><?php echo e(number_format($monthlyServices ?? 0)); ?></div>
                    <div class="stat-label">Monthly Services</div>
                    <div class="stat-change"><?php echo e($currentMonthName ?? 'Current Month'); ?></div>
                </div>
            </div>

            <!-- Medicine Inventory Card -->
            <div class="stat-card">
                <div class="stat-icon stat-icon-orange">
                    <i class="bi bi-capsule"></i>
                </div>
                <div class="stat-details">
                    <div class="stat-value"><?php echo e(number_format($totalMedicineStock ?? 0)); ?></div>
                    <div class="stat-label">Medicine Stock</div>
                    <div class="stat-change">Available Items</div>
                </div>
            </div>
        </div>

        <!-- Health Programs Overview Section -->
        <div class="program-summary">
            <div class="section-header-inline">
                <h2>Health Programs Overview</h2>
                <p>Quick access to health program records and statistics</p>
            </div>

            <div class="program-cards">
                <!-- Prenatal Care Services -->
                <div class="program-card">
                    <div class="program-icon">
                        <i class="bi bi-heart-pulse"></i>
                    </div>
                    <div class="program-content">
                        <h3>Prenatal Care Services</h3>
                        <p class="program-count"><?php echo e($prenatalTotal ?? 0); ?> Registered Pregnant Women</p>
                        <a href="<?php echo e(route('health-programs.prenatal-view')); ?>" class="btn-link">
                            View Records <i class="bi bi-arrow-right"></i>
                        </a>
                    </div>
                </div>

                <!-- Family Planning Services -->
                <div class="program-card">
                    <div class="program-icon">
                        <i class="bi bi-people-fill"></i>
                    </div>
                    <div class="program-content">
                        <h3>Family Planning Services</h3>
                        <p class="program-count"><?php echo e($familyPlanningTotal ?? 0); ?> Active FP Clients</p>
                        <a href="<?php echo e(route('health-programs.family-planning-view')); ?>" class="btn-link">
                            View Records <i class="bi bi-arrow-right"></i>
                        </a>
                    </div>
                </div>

                <!-- Immunization Program (NIP) -->
                <div class="program-card">
                    <div class="program-icon">
                        <i class="bi bi-shield-check"></i>
                    </div>
                    <div class="program-content">
                        <h3>Immunization Program</h3>
                        <p class="program-count"><?php echo e($nipTotal ?? 0); ?> Children Enrolled</p>
                        <a href="<?php echo e(route('health-programs.new-nip-view')); ?>" class="btn-link">
                            View Records <i class="bi bi-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Statistical Analysis Section (Admins only) -->
        <?php if(in_array($role, ['super_admin', 'admin'])): ?>
            <div class="charts-section">
                <div class="section-header-inline">
                    <h2>Statistical Analysis</h2>
                    <p>Visual insights into health center performance and trends</p>
                </div>

                <div class="charts-grid">
                    <!-- Monthly Services Trend -->
                    <div class="chart-card" onclick="window.location.href='<?php echo e(route('reports.monthly')); ?>'">
                        <div class="chart-header">
                            <h3><i class="bi bi-graph-up"></i> Monthly Services Trend</h3>
                            <span class="chart-badge">Last 6 Months</span>
                        </div>
                        <div class="chart-placeholder">
                            <canvas id="consultationsChart"></canvas>
                        </div>
                        <p class="chart-footer">Click to view detailed monthly reports</p>
                    </div>

                    <!-- Program Distribution -->
                    <div class="chart-card" onclick="window.location.href='<?php echo e(route('reports.monthly')); ?>'">
                        <div class="chart-header">
                            <h3><i class="bi bi-pie-chart"></i> Program Distribution</h3>
                            <span class="chart-badge"><?php echo e($currentMonthName ?? 'Current'); ?></span>
                        </div>
                        <div class="chart-placeholder">
                            <canvas id="programsChart"></canvas>
                        </div>
                        <p class="chart-footer">Click to view program statistics</p>
                    </div>

                    <!-- Medicine Dispensing -->
                    <div class="chart-card" onclick="window.location.href='<?php echo e(route('reports.monthly')); ?>'">
                        <div class="chart-header">
                            <h3><i class="bi bi-bar-chart-line"></i> Medicine Dispensing</h3>
                            <span class="chart-badge">Weekly</span>
                        </div>
                        <div class="chart-placeholder">
                            <canvas id="medicineChart"></canvas>
                        </div>
                        <p class="chart-footer">Click to view inventory reports</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Monthly Statistics Section -->
        <div class="monthly-stats" style="max-width: 100%;">
            <div class="section-header-inline">
                <h2>Monthly Service Summary</h2>
                <p>Compare current month with previous month performance</p>
            </div>

            <div class="stats-table">
                <table>
                    <thead>
                        <tr>
                            <th>Service Category</th>
                            <th><?php echo e($currentMonthName ?? 'Current'); ?></th>
                            <th>Previous Month</th>
                            <th>Variance</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Prenatal Care Consultations</strong></td>
                            <td><?php echo e($summary['prenatal']['current'] ?? 0); ?></td>
                            <td><?php echo e($summary['prenatal']['previous'] ?? 0); ?></td>
                            <?php
                                $prenatalVar = $summary['prenatal']['variance'] ?? 0;
                            ?>
                            <td class="<?php echo e($prenatalVar >= 0 ? 'positive' : 'negative'); ?>">
                                <i class="bi bi-<?php echo e($prenatalVar >= 0 ? 'arrow-up' : 'arrow-down'); ?>"></i>
                                <?php echo e($prenatalVar >= 0 ? '+' : ''); ?><?php echo e($prenatalVar); ?>%
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Family Planning Services</strong></td>
                            <td><?php echo e($summary['fp']['current'] ?? 0); ?></td>
                            <td><?php echo e($summary['fp']['previous'] ?? 0); ?></td>
                            <?php
                                $fpVar = $summary['fp']['variance'] ?? 0;
                            ?>
                            <td class="<?php echo e($fpVar >= 0 ? 'positive' : 'negative'); ?>">
                                <i class="bi bi-<?php echo e($fpVar >= 0 ? 'arrow-up' : 'arrow-down'); ?>"></i>
                                <?php echo e($fpVar >= 0 ? '+' : ''); ?><?php echo e($fpVar); ?>%
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Immunizations Administered</strong></td>
                            <td><?php echo e($summary['nip']['current'] ?? 0); ?></td>
                            <td><?php echo e($summary['nip']['previous'] ?? 0); ?></td>
                            <?php
                                $nipVar = $summary['nip']['variance'] ?? 0;
                            ?>
                            <td class="<?php echo e($nipVar >= 0 ? 'positive' : 'negative'); ?>">
                                <i class="bi bi-<?php echo e($nipVar >= 0 ? 'arrow-up' : 'arrow-down'); ?>"></i>
                                <?php echo e($nipVar >= 0 ? '+' : ''); ?><?php echo e($nipVar); ?>%
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Medicine Items Dispensed</strong></td>
                            <td><?php echo e($summary['medicine']['current'] ?? 0); ?></td>
                            <td><?php echo e($summary['medicine']['previous'] ?? 0); ?></td>
                            <?php
                                $medVar = $summary['medicine']['variance'] ?? 0;
                            ?>
                            <td class="<?php echo e($medVar >= 0 ? 'positive' : 'negative'); ?>">
                                <i class="bi bi-<?php echo e($medVar >= 0 ? 'arrow-up' : 'arrow-down'); ?>"></i>
                                <?php echo e($medVar >= 0 ? '+' : ''); ?><?php echo e($medVar); ?>%
                            </td>
                        </tr>
                        <tr>
                            <td><strong>New Patient Registrations</strong></td>
                            <td><?php echo e($summary['patients']['current'] ?? 0); ?></td>
                            <td><?php echo e($summary['patients']['previous'] ?? 0); ?></td>
                            <?php
                                $patVar = $summary['patients']['variance'] ?? 0;
                            ?>
                            <td class="<?php echo e($patVar >= 0 ? 'positive' : 'negative'); ?>">
                                <i class="bi bi-<?php echo e($patVar >= 0 ? 'arrow-up' : 'arrow-down'); ?>"></i>
                                <?php echo e($patVar >= 0 ? '+' : ''); ?><?php echo e($patVar); ?>%
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Monthly Services Trend Chart
        const servicesLabels = <?php echo json_encode($monthLabels ?? [], 15, 512) ?>;
        const servicesData = <?php echo json_encode($servicesSeries ?? [], 15, 512) ?>;

        const ctx1 = document.getElementById('consultationsChart');
        if (ctx1) {
            new Chart(ctx1.getContext('2d'), {
                type: 'line',
                data: {
                    labels: servicesLabels,
                    datasets: [{
                        label: 'Health Services Provided',
                        data: servicesData,
                        borderColor: '#3498db',
                        backgroundColor: 'rgba(52, 152, 219, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            padding: 12,
                            titleFont: { size: 14 },
                            bodyFont: { size: 13 }
                        }
                    },
                    scales: {
                        y: { beginAtZero: true }
                    }
                }
            });
        }

        // Health Programs Distribution Chart
        const programData = <?php echo json_encode(array_values($programDistribution ?? []), 15, 512) ?>;
        const ctx2 = document.getElementById('programsChart');
        if (ctx2) {
            new Chart(ctx2.getContext('2d'), {
                type: 'doughnut',
                data: {
                    labels: ['Prenatal Care', 'Family Planning', 'Immunization (NIP)'],
                    datasets: [{
                        data: programData,
                        backgroundColor: ['#e74c3c', '#9b59b6', '#2ecc71'],
                        borderWidth: 3,
                        borderColor: '#fff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 15,
                                font: { size: 12 }
                            }
                        }
                    }
                }
            });
        }

        // Medicine Dispensing Chart
        const weekLabels = <?php echo json_encode($weeksLabels ?? [], 15, 512) ?>;
        const weekData = <?php echo json_encode($weeksData ?? [], 15, 512) ?>;
        const ctx3 = document.getElementById('medicineChart');
        if (ctx3) {
            new Chart(ctx3.getContext('2d'), {
                type: 'bar',
                data: {
                    labels: weekLabels,
                    datasets: [{
                        label: 'Medicine Items Dispensed',
                        data: weekData,
                        backgroundColor: '#3498db',
                        borderRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            padding: 12
                        }
                    },
                    scales: {
                        y: { beginAtZero: true }
                    }
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\source\repos\IT12_Brgy_HealthCareMS\resources\views\dashboard\bhw.blade.php ENDPATH**/ ?>