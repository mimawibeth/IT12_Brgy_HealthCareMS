<?php $__env->startSection('title', 'Patient List'); ?>
<?php $__env->startSection('page-title', 'Patient List'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/patients.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">

        <!-- Search and Filter Section -->
        <form method="GET" action="<?php echo e(route('patients.index')); ?>" class="filters">
            <div class="search-box">
                <input type="text" name="search" placeholder="Search patients..." class="search-input"
                    value="<?php echo e(request('search')); ?>">
                <button type="submit" class="btn-search"><i class="bi bi-search"></i> Search</button>
                <a href="<?php echo e(route('patients.create')); ?>" class="btn btn-primary" style="margin-left: 10px;">
                    <i class="bi bi-person-plus"></i> Add New Patient
                </a>
            </div>

            <div class="filter-options">
                <select name="gender" class="filter-select">
                    <option value="">All Gender</option>
                    <option value="male" <?php echo e(request('gender') === 'male' ? 'selected' : ''); ?>>Male</option>
                    <option value="female" <?php echo e(request('gender') === 'female' ? 'selected' : ''); ?>>Female</option>
                </select>

                <select name="age_group" class="filter-select">
                    <option value="">All Ages</option>
                    <option value="child" <?php echo e(request('age_group') === 'child' ? 'selected' : ''); ?>>Children (0-12)
                    </option>
                    <option value="teen" <?php echo e(request('age_group') === 'teen' ? 'selected' : ''); ?>>Teenagers (13-19)
                    </option>
                    <option value="adult" <?php echo e(request('age_group') === 'adult' ? 'selected' : ''); ?>>Adults (20-59)
                    </option>
                    <option value="senior" <?php echo e(request('age_group') === 'senior' ? 'selected' : ''); ?>>Senior (60+)
                    </option>
                </select>
            </div>
        </form>

        <!-- Patients Table -->
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Date Registered</th>
                        <th>Patient No.</th>
                        <th>Name</th>
                        <th>Sex</th>
                        <th>Birthday</th>
                        <th>Address</th>
                        <th>Contact Number</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <?php echo e($patient->dateRegistered ? \Carbon\Carbon::parse($patient->dateRegistered)->format('M d, Y') : ''); ?>

                            </td>
                            <td><?php echo e($patient->patientNo); ?></td>
                            <td><?php echo e($patient->name); ?></td>
                            <td><?php echo e($patient->sex); ?></td>
                            <td>
                                <?php echo e($patient->birthday ? \Carbon\Carbon::parse($patient->birthday)->format('M d, Y') : ''); ?>

                            </td>
                            <td><?php echo e($patient->address); ?></td>
                            <td><?php echo e($patient->contactNumber); ?></td>
                            <td class="actions">
                                <a href="#" class="btn-action btn-view" data-patient-id="<?php echo e($patient->PatientID); ?>">
                                    <i class="bi bi-eye"></i> View
                                </a>
                                <a href="<?php echo e(route('patients.edit', $patient->PatientID)); ?>" class="btn-action btn-edit">
                                    <i class="bi bi-pencil"></i> Edit
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" style="text-align: center;">No patients found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($patients->hasPages()): ?>
            <div class="pagination">
                <?php if($patients->onFirstPage()): ?>
                    <button class="btn-page" disabled>« Previous</button>
                <?php else: ?>
                    <a class="btn-page" href="<?php echo e($patients->previousPageUrl()); ?>">« Previous</a>
                <?php endif; ?>

                <?php
                    $start = max(1, $patients->currentPage() - 2);
                    $end = min($patients->lastPage(), $patients->currentPage() + 2);
                ?>

                <?php for($page = $start; $page <= $end; $page++): ?>
                    <?php if($page === $patients->currentPage()): ?>
                        <span class="btn-page active"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a class="btn-page" href="<?php echo e($patients->url($page)); ?>"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endfor; ?>

                <span class="page-info">
                    Page <?php echo e($patients->currentPage()); ?> of <?php echo e($patients->lastPage()); ?> (<?php echo e($patients->total()); ?> total patients)
                </span>

                <?php if($patients->hasMorePages()): ?>
                    <a class="btn-page" href="<?php echo e($patients->nextPageUrl()); ?>">Next »</a>
                <?php else: ?>
                    <button class="btn-page" disabled>Next »</button>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- Patient View Modal -->
        <div id="patientViewModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Patient Details</h3>
                    <span class="close-modal" onclick="closePatientViewModal()">&times;</span>
                </div>

                <div class="modal-body">
                    <!-- Section 1: Patient Information (from ITR) -->
                    <div class="form-section section-patient-info">
                        <h4 class="section-header"><span class="section-indicator"></span>Patient Information</h4>

                        <div class="form-row">
                            <div class="form-group full-width">
                                <label>Full Name</label>
                                <p id="modalName"></p>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label>Patient No.</label>
                                <p id="modalPatientNo"></p>
                            </div>
                            <div class="form-group">
                                <label>Sex</label>
                                <p id="modalSex"></p>
                            </div>
                            <div class="form-group">
                                <label>Birthday</label>
                                <p id="modalBirthday"></p>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group full-width">
                                <label>Address</label>
                                <p id="modalAddress"></p>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label>Contact Number</label>
                                <p id="modalContactNumber"></p>
                            </div>
                            <div class="form-group">
                                <label>Date Registered</label>
                                <p id="modalDateRegistered"></p>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label>NHTS ID No.</label>
                                <p id="modalNhtsIdNo"></p>
                            </div>
                            <div class="form-group">
                                <label>PWD ID No.</label>
                                <p id="modalPwdIdNo"></p>
                            </div>
                            <div class="form-group">
                                <label>PHIC ID No.</label>
                                <p id="modalPhicIdNo"></p>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label>4Ps/CCT ID No.</label>
                                <p id="modalFourPsCctIdNo"></p>
                            </div>
                            <div class="form-group">
                                <label>Ethnic Group</label>
                                <p id="modalEthnicGroup"></p>
                            </div>
                        </div>
                    </div>

                    <!-- Section 2: Latest Health Assessment (Initial Visit Assessment) -->
                    <div class="form-section section-assessment">
                        <h4 class="section-header"><span class="section-indicator"></span>Initial Visit Assessment -
                            Monitoring Parameters</h4>

                        <div class="form-row">
                            <div class="form-group">
                                <label>Assessment Date</label>
                                <p id="modalAssessmentDate"></p>
                            </div>
                            <div class="form-group">
                                <label>Age</label>
                                <p id="modalAssessmentAge"></p>
                            </div>
                            <div class="form-group">
                                <label>CVD Risk</label>
                                <p id="modalAssessmentCvdRisk"></p>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label>BP Systolic (mmHg)</label>
                                <p id="modalAssessmentBpSystolic"></p>
                            </div>
                            <div class="form-group">
                                <label>BP Diastolic (mmHg)</label>
                                <p id="modalAssessmentBpDiastolic"></p>
                            </div>
                            <div class="form-group">
                                <label>Weight (kg)</label>
                                <p id="modalAssessmentWt"></p>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label>Height (cm)</label>
                                <p id="modalAssessmentHt"></p>
                            </div>
                            <div class="form-group">
                                <label>FBS/RBS (mg/dL)</label>
                                <p id="modalAssessmentFbsRbs"></p>
                            </div>
                            <div class="form-group">
                                <label>Lipid Profile</label>
                                <p id="modalAssessmentLipidProfile"></p>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group full-width">
                                <label>Chief Complaint</label>
                                <p id="modalAssessmentChiefComplaint"></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn btn-secondary" onclick="closePatientViewModal()">
                        Close
                    </button>
                </div>
            </div>
        </div>

    </div>

    <script>
        function openPatientViewModal(patientId) {
            fetch('<?php echo e(route('patients.index')); ?>/' + patientId)
                .then(response => response.json())
                .then(data => {
                    const patient = data.patient || data;

                    const formatDate = (value) => {
                        if (!value) return '';
                        const d = new Date(value);
                        if (isNaN(d.getTime())) {
                            return value;
                        }
                        return d.toLocaleDateString('en-US', {
                            month: 'short',
                            day: '2-digit',
                            year: 'numeric'
                        });
                    };

                    document.getElementById('modalDateRegistered').textContent = formatDate(patient.dateRegistered);
                    document.getElementById('modalPatientNo').textContent = patient.patientNo || '';
                    document.getElementById('modalSex').textContent = patient.sex || '';
                    document.getElementById('modalName').textContent = patient.name || '';
                    document.getElementById('modalBirthday').textContent = formatDate(patient.birthday);
                    document.getElementById('modalContactNumber').textContent = patient.contactNumber || '';
                    document.getElementById('modalAddress').textContent = patient.address || '';
                    document.getElementById('modalNhtsIdNo').textContent = patient.nhtsIdNo || '';
                    document.getElementById('modalPwdIdNo').textContent = patient.pwdIdNo || '';
                    document.getElementById('modalPhicIdNo').textContent = patient.phicIdNo || '';
                    document.getElementById('modalFourPsCctIdNo').textContent = patient.fourPsCctIdNo || '';
                    document.getElementById('modalEthnicGroup').textContent = patient.ethnicGroup || '';

                    const assessments = data.assessments || patient.assessments || [];
                    const latest = assessments.length ? assessments[assessments.length - 1] : null;

                    document.getElementById('modalAssessmentDate').textContent = latest ? formatDate(latest.date) : '';
                    document.getElementById('modalAssessmentAge').textContent = latest && latest.age ? latest.age : '';
                    document.getElementById('modalAssessmentCvdRisk').textContent = latest && latest.cvdRisk ? latest.cvdRisk : '';
                    document.getElementById('modalAssessmentBpSystolic').textContent = latest && latest.bpSystolic ? latest.bpSystolic : '';
                    document.getElementById('modalAssessmentBpDiastolic').textContent = latest && latest.bpDiastolic ? latest.bpDiastolic : '';
                    document.getElementById('modalAssessmentWt').textContent = latest && latest.wt ? latest.wt : '';
                    document.getElementById('modalAssessmentHt').textContent = latest && latest.ht ? latest.ht : '';
                    document.getElementById('modalAssessmentFbsRbs').textContent = latest && latest.fbsRbs ? latest.fbsRbs : '';
                    document.getElementById('modalAssessmentLipidProfile').textContent = latest && latest.lipidProfile ? latest.lipidProfile : '';
                    document.getElementById('modalAssessmentChiefComplaint').textContent = latest && latest.chiefComplaint ? latest.chiefComplaint : '';

                    document.getElementById('patientViewModal').style.display = 'flex';
                });
        }

        function closePatientViewModal() {
            document.getElementById('patientViewModal').style.display = 'none';
        }

        document.addEventListener('DOMContentLoaded', function () {
            const viewButtons = document.querySelectorAll('.btn-view');

            viewButtons.forEach(button => {
                button.addEventListener('click', function (e) {
                    e.preventDefault();
                    const patientId = this.getAttribute('data-patient-id');
                    if (patientId) {
                        openPatientViewModal(patientId);
                    }
                });
            });

            window.addEventListener('click', function (event) {
                const modal = document.getElementById('patientViewModal');
                if (event.target === modal) {
                    closePatientViewModal();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\source\repos\IT12_Brgy_HealthCareMS\resources\views\patients\index.blade.php ENDPATH**/ ?>