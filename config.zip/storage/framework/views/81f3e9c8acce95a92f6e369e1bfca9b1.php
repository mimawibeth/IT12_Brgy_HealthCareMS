<?php $__env->startSection('title', 'All Users'); ?>
<?php $__env->startSection('page-title', 'All Users'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/patients.css?v=' . time())); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/users.css?v=' . time())); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <!-- Search and Filter Section -->
        <div class="filters">
            <div class="search-box">
                <input type="text" placeholder="Search users by name, username, email..." class="search-input">
                <button class="btn btn-primary"><i class="bi bi-search"></i> Search</button>
                <a href="<?php echo e(route('users.add-new')); ?>" class="btn btn-primary">
                    <i class="bi bi-person-plus"></i> Add New User
                </a>
            </div>

            <div class="filter-options">
                <select class="filter-select">
                    <option value="">All Roles</option>
                    <option value="super_admin">Super Admin</option>
                    <option value="admin">Admin</option>
                    <option value="bhw">Barangay Health Worker</option>
                </select>

                <select class="filter-select">
                    <option value="">All Status</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
        </div>

        <!-- Users Table -->
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Created Date</th>
                        <th>Last Login</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $fullName = trim(($user->first_name ?? '') . ' ' . ($user->middle_name ? $user->middle_name . ' ' : '') . ($user->last_name ?? '')) ?: ($user->name ?? 'N/A');
                            $roleBadges = [
                                'super_admin' => ['label' => 'Super Admin', 'class' => 'badge-super-admin'],
                                'admin' => ['label' => 'Admin', 'class' => 'badge-admin'],
                                'bhw' => ['label' => 'BHW', 'class' => 'badge-bhw'],
                            ];
                            $roleMeta = $roleBadges[$user->role ?? 'bhw'] ?? ['label' => ucfirst($user->role ?? 'User'), 'class' => 'badge-admin'];
                        ?>
                        <tr>
                            <td><?php echo e($user->username ?? 'N/A'); ?></td>
                            <td><?php echo e($fullName); ?></td>
                            <td><?php echo e($user->email ?? 'N/A'); ?></td>
                            <td><span class="badge <?php echo e($roleMeta['class']); ?>"><?php echo e($roleMeta['label']); ?></span></td>
                            <td>
                                <?php if(($user->status ?? 'inactive') === 'active'): ?>
                                    <span class="status-badge status-active">Active</span>
                                <?php else: ?>
                                    <span class="status-badge status-inactive">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(optional($user->created_at)->format('M d, Y') ?? 'N/A'); ?></td>
                            <td>—</td>
                            <td class="actions">
                                <a href="javascript:void(0)" class="btn-action btn-view view-user"
                                    data-id="<?php echo e($user->id); ?>">View</a>
                                <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn-action btn-edit">Edit</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" style="text-align:center;">No users found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php
            $showPagination = !empty($users) && method_exists($users, 'hasPages') && $users->hasPages();
        ?>
        <?php if($showPagination): ?>
            <div class="pagination">
                <?php if($users->onFirstPage()): ?>
                    <button class="btn-page" disabled>« Previous</button>
                <?php else: ?>
                    <a class="btn-page" href="<?php echo e($users->previousPageUrl()); ?>">« Previous</a>
                <?php endif; ?>

                <?php
                    $start = max(1, $users->currentPage() - 2);
                    $end = min($users->lastPage(), $users->currentPage() + 2);
                ?>

                <?php for($page = $start; $page <= $end; $page++): ?>
                    <?php if($page === $users->currentPage()): ?>
                        <span class="btn-page active"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a class="btn-page" href="<?php echo e($users->url($page)); ?>"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endfor; ?>

                <span class="page-info">
                    Page <?php echo e($users->currentPage()); ?> of <?php echo e($users->lastPage()); ?> (<?php echo e($users->total()); ?> total users)
                </span>

                <?php if($users->hasMorePages()): ?>
                    <a class="btn-page" href="<?php echo e($users->nextPageUrl()); ?>">Next »</a>
                <?php else: ?>
                    <button class="btn-page" disabled>Next »</button>
                <?php endif; ?>
            </div>
        <?php endif; ?>

    </div>

    <?php echo $__env->make('users.partials.view-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\source\repos\IT12_Brgy_HealthCareMS\resources\views\users\all-users.blade.php ENDPATH**/ ?>