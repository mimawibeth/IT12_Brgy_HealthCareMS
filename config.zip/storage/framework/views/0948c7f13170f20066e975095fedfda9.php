<?php $__env->startSection('title', 'Audit Logs'); ?>
<?php $__env->startSection('page-title', 'Audit Logs'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/patients.css?v=' . time())); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/audit-logs.css?v=' . time())); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <!-- Summary Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon stat-icon-blue">
                    <i class="bi bi-activity"></i>
                </div>
                <div class="stat-details">
                    <div class="stat-value"><?php echo e($stats['totalToday'] ?? 0); ?></div>
                    <div class="stat-label">Total Activities Today</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon stat-icon-green">
                    <i class="bi bi-check-circle"></i>
                </div>
                <div class="stat-details">
                    <div class="stat-value"><?php echo e($stats['successToday'] ?? 0); ?></div>
                    <div class="stat-label">Successful Actions</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon stat-icon-red">
                    <i class="bi bi-x-circle"></i>
                </div>
                <div class="stat-details">
                    <div class="stat-value"><?php echo e($stats['failedToday'] ?? 0); ?></div>
                    <div class="stat-label">Failed Attempts</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon stat-icon-purple">
                    <i class="bi bi-people"></i>
                </div>
                <div class="stat-details">
                    <div class="stat-value"><?php echo e($stats['activeUsersToday'] ?? 0); ?></div>
                    <div class="stat-label">Active Users</div>
                </div>
            </div>
        </div>

        <!-- Filter Section -->
        <div class="filters">
            <form id="logs-filters-form" method="GET" action="<?php echo e(route('logs.audit')); ?>">
                <div class="search-box">
                    <input type="text" name="search" placeholder="Search logs by description, module, or IP address..."
                        class="search-input" value="<?php echo e(request('search')); ?>">
                    <button class="btn btn-primary" type="button" onclick="applyFilters()">
                        <i class="bi bi-search"></i> Search
                    </button>
                    <button class="btn btn-secondary" type="button" onclick="exportLogs()">
                        <i class="bi bi-download"></i> Export Logs
                    </button>
                </div>
                <div class="filter-options">
                    <input type="date" name="date_from" class="filter-select" value="<?php echo e(request('date_from')); ?>">
                    <input type="date" name="date_to" class="filter-select" value="<?php echo e(request('date_to')); ?>">
                    <button class="btn btn-secondary" type="button" onclick="clearFilters()">
                        Clear Filters
                    </button>
                </div>
            </form>
        </div>

        <!-- Audit Logs Table -->
        <div class="table-container">

            <div style="overflow-x: auto;">
                <table class="data-table" style="min-width: 900px;">
                    <thead>
                        <tr>
                            <th>Timestamp</th>
                            <th>User</th>
                            <th>Action</th>
                            <th>Module</th>
                            <th>Description</th>
                            <th>IP Address</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $user = $log->user;
                                $role = $log->user_role ?? ($user->role ?? null);
                                $roleBadgeClass = 'badge-unknown';
                                $roleLabel = 'N/A';
                                if ($role === 'super_admin') {
                                    $roleBadgeClass = 'badge-super-admin';
                                    $roleLabel = 'Super Admin';
                                } elseif ($role === 'admin') {
                                    $roleBadgeClass = 'badge-admin';
                                    $roleLabel = 'Admin';
                                } elseif ($role === 'bhw') {
                                    $roleBadgeClass = 'badge-bhw';
                                    $roleLabel = 'BHW';
                                }

                                $actionClass = 'action-view';
                                if ($log->action === 'login') {
                                    $actionClass = 'action-login';
                                } elseif ($log->action === 'logout') {
                                    $actionClass = 'action-logout';
                                } elseif ($log->action === 'create') {
                                    $actionClass = 'action-create';
                                } elseif ($log->action === 'update') {
                                    $actionClass = 'action-update';
                                } elseif ($log->action === 'delete') {
                                    $actionClass = 'action-delete';
                                } elseif ($log->action === 'export') {
                                    $actionClass = 'action-export';
                                }

                                $statusClass = $log->status === 'failed' ? 'status-failed' : 'status-success';
                            ?>
                            <tr>
                                <td>
                                    <div style="white-space: nowrap;">
                                        <?php echo e($log->created_at ? $log->created_at->format('M d, Y') : '—'); ?>

                                        <br>
                                        <small
                                            style="color: #7f8c8d;"><?php echo e($log->created_at ? $log->created_at->format('g:i:s A') : '—'); ?></small>
                                    </div>
                                </td>
                                <td>
                                    <div class="user-info">
                                        <span class="user-name"><?php echo e($user->name ?? 'System'); ?></span>
                                        <span class="user-badge <?php echo e($roleBadgeClass); ?>"><?php echo e($roleLabel); ?></span>
                                    </div>
                                </td>
                                <td>
                                    <span class="action-badge <?php echo e($actionClass); ?>"><?php echo e(ucfirst($log->action ?? 'other')); ?></span>
                                </td>
                                <td><?php echo e($log->module ?? '—'); ?></td>
                                <td style="max-width: 300px;" title="<?php echo e($log->description ?? '—'); ?>">
                                    <?php
                                        $desc = $log->description ?? '—';
                                        $truncated = strlen($desc) > 60 ? substr($desc, 0, 60) . '...' : $desc;
                                    ?>
                                    <?php echo e($truncated); ?>

                                </td>
                                <td>
                                    <code style="font-size: 12px; color: #555;"><?php echo e($log->ip_address ?? '—'); ?></code>
                                </td>
                                <td>
                                    <span
                                        class="status-badge <?php echo e($statusClass); ?>"><?php echo e(ucfirst($log->status ?? 'unknown')); ?></span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" style="text-align: center;">No logs found for the selected filters.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php
            $showPagination = !empty($logs) && method_exists($logs, 'hasPages') && $logs->hasPages();
        ?>
        <?php if($showPagination): ?>
            <div class="pagination">
                <?php if($logs->onFirstPage()): ?>
                    <button class="btn-page" disabled>« Previous</button>
                <?php else: ?>
                    <a class="btn-page" href="<?php echo e($logs->previousPageUrl()); ?>">« Previous</a>
                <?php endif; ?>

                <?php
                    $start = max(1, $logs->currentPage() - 2);
                    $end = min($logs->lastPage(), $logs->currentPage() + 2);
                ?>

                <?php for($page = $start; $page <= $end; $page++): ?>
                    <?php if($page === $logs->currentPage()): ?>
                        <span class="btn-page active"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a class="btn-page" href="<?php echo e($logs->url($page)); ?>"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endfor; ?>

                <span class="page-info">
                    Page <?php echo e($logs->currentPage()); ?> of <?php echo e($logs->lastPage()); ?> (<?php echo e($logs->total()); ?> total logs)
                </span>

                <?php if($logs->hasMorePages()): ?>
                    <a class="btn-page" href="<?php echo e($logs->nextPageUrl()); ?>">Next »</a>
                <?php else: ?>
                    <button class="btn-page" disabled>Next »</button>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function applyFilters() {
            const form = document.getElementById('logs-filters-form');
            if (form) {
                form.submit();
            }
        }

        function clearFilters() {
            window.location.href = '<?php echo e(route('logs.audit')); ?>';
        }

        function exportLogs() {
            alert('Export functionality will be implemented with backend');
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\source\repos\IT12_Brgy_HealthCareMS\resources\views\logs\audit.blade.php ENDPATH**/ ?>